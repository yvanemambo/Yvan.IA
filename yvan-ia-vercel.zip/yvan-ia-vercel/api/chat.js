// Yvan.IA - fonction serveur (tourne sur Vercel). La clé API reste ici, jamais dans la page.
const SYSTEME = `Tu es Yvan.IA, un assistant vocal personnel. Tu réponds en français,
en phrases courtes et naturelles, sans markdown ni listes à puces, car ta réponse
est lue à voix haute. Si un document ou une image est joint, analyse-le précisément.
S'il manque une information, dis-le clairement au lieu d'inventer.`;

const TYPES_OK = ['application/pdf', 'text/plain', 'image/png', 'image/jpeg', 'image/webp'];

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ erreur: 'Méthode non autorisée' });

  const { GEMINI_API_KEY, YVAN_CODE } = process.env;
  const modele = process.env.GEMINI_MODEL || 'gemini-2.5-flash';

  if (!GEMINI_API_KEY || !YVAN_CODE) {
    return res.status(500).json({ erreur: 'Configuration manquante sur Vercel (GEMINI_API_KEY et YVAN_CODE).' });
  }
  if (req.headers['x-code'] !== YVAN_CODE) {
    return res.status(401).json({ erreur: "Code d'accès incorrect" });
  }

  const { messages = [], fichier } = req.body || {};
  let hist = messages.slice(-12).filter(m => m && m.text);
  while (hist.length && hist[0].role !== 'user') hist.shift();
  if (!hist.length) return res.status(400).json({ erreur: 'Message vide' });

  const contents = hist.map(m => ({
    role: m.role === 'model' ? 'model' : 'user',
    parts: [{ text: String(m.text).slice(0, 4000) }]
  }));

  if (fichier && fichier.data && TYPES_OK.includes(fichier.mime)) {
    contents[contents.length - 1].parts.push({
      inlineData: { mimeType: fichier.mime, data: fichier.data }
    });
  }

  try {
    const r = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${modele}:generateContent`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-goog-api-key': GEMINI_API_KEY },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: SYSTEME }] },
          contents
        })
      }
    );
    const data = await r.json();
    if (r.status === 429) {
      return res.status(429).json({ erreur: 'Limite gratuite atteinte. Réessaie dans une minute.' });
    }
    if (!r.ok) {
      return res.status(502).json({ erreur: (data.error && data.error.message) || 'Erreur Gemini' });
    }
    const texte = ((data.candidates || [])[0]?.content?.parts || []).map(p => p.text || '').join('').trim();
    return res.status(200).json({ reponse: texte || "Je n'ai pas de réponse, reformule s'il te plaît." });
  } catch (e) {
    return res.status(500).json({ erreur: 'Problème côté serveur : ' + e.message });
  }
};
